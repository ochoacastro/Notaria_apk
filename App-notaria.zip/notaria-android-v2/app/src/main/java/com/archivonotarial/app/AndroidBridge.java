package com.archivonotarial.app;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;
import android.util.Log;
import android.webkit.JavascriptInterface;

/**
 * Puente entre el WebView (JavaScript) y Android.
 *
 * Accesible desde JS como:  window.AndroidBridge.<método>()
 *
 * Uso en index.html (ya inyectado por MainActivity):
 *   const ip = window.AndroidBridge ? window.AndroidBridge.getWifiIp() : '';
 */
public class AndroidBridge {

    private static final String TAG = "AndroidBridge";
    private final Context context;
    private final MainActivity activity;

    public AndroidBridge(Context ctx, MainActivity act) {
        this.context  = ctx;
        this.activity = act;
    }

    /** Devuelve la IP WiFi del dispositivo (e.g. "192.168.1.5") o "" si no está conectado. */
    @JavascriptInterface
    public String getWifiIp() {
        try {
            WifiManager wm = (WifiManager) context.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm == null) return "";
            int ipInt = wm.getConnectionInfo().getIpAddress();
            if (ipInt == 0) return "";
            return Formatter.formatIpAddress(ipInt);
        } catch (Exception e) {
            Log.e(TAG, "getWifiIp", e);
            return "";
        }
    }

    /** Arranca el servidor LAN (llamado por JS cuando el modo es "servidor"). */
    @JavascriptInterface
    public void startLanServer() {
        activity.runOnUiThread(() -> activity.startLanServer());
    }

    /** Detiene el servidor LAN. */
    @JavascriptInterface
    public void stopLanServer() {
        activity.runOnUiThread(() -> activity.stopLanServer());
    }

    /** Indica si el servidor está activo. */
    @JavascriptInterface
    public boolean isLanServerRunning() {
        return activity.isLanServerRunning();
    }

    /** Guarda info del grupo (nombre, admin) en disco para que los clientes la lean vía /api/info. */
    @JavascriptInterface
    public void setGrupoInfo(String grupoNombre, String adminNombre) {
        activity.setGrupoInfo(grupoNombre, adminNombre);
    }

    /**
     * Persiste el array completo de escrituras en lan_escrituras.json,
     * el archivo que LanServer sirve a los clientes.
     * Llamar siempre que el servidor cree, edite, elimine o importe escrituras.
     */
    @JavascriptInterface
    public void saveEscrituras(String jsonArray) {
        activity.saveLanEscrituras(jsonArray);
    }

    /**
     * Persiste el array completo de actividad en lan_actividad.json.
     */
    @JavascriptInterface
    public void saveActividad(String jsonArray) {
        activity.saveLanActividad(jsonArray);
    }
}
