package com.archivonotarial.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Color;

import java.io.IOException;

public class MainActivity extends Activity {

    private static final String TAG = "MainActivity";

    private WebView webView;
    private LanServer lanServer;
    private AndroidBridge bridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Pantalla completa sin título
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#F0EDE8"));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);

        // ── Puente JS ↔ Android ────────────────────────────────────────
        bridge = new AndroidBridge(this, this);
        webView.addJavascriptInterface(bridge, "AndroidBridge");

        // ── Inyectar IP WiFi en window.LAN_IP antes de que cargue el JS ─
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(android.webkit.WebView view, String url) {
                String ip = bridge.getWifiIp();
                if (ip != null && !ip.isEmpty()) {
                    // Inyectar la IP para que el JS la use en window.LAN_IP
                    view.evaluateJavascript(
                        "window.LAN_IP = '" + ip + "';", null);
                    Log.d(TAG, "LAN_IP inyectada: " + ip);
                }
            }
        });
        webView.setWebChromeClient(new WebChromeClient());

        webView.loadUrl("file:///android_asset/www/index.html");
    }

    // ── LAN Server lifecycle ───────────────────────────────────────────

    /** Llamado desde AndroidBridge (JS → Java) cuando el modo es "servidor". */
    public void startLanServer() {
        if (lanServer != null && lanServer.isAlive()) {
            Log.d(TAG, "LanServer ya está corriendo");
            return;
        }
        try {
            lanServer = new LanServer(this);
            lanServer.setAccessListener((ip, ua, nombre) -> {
                // Escapa comillas simples para no romper el JS
                String safeIp     = ip.replace("'", "\\'");
                String safeUa     = ua.replace("'", "\\'");
                String safeNombre = nombre.replace("'", "\\'");
                String js = "if(typeof redRegistrarAcceso==='function')" +
                            "redRegistrarAcceso('" + safeIp + "','" + safeUa + "','" + safeNombre + "');";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            });
            lanServer.start();
            Log.d(TAG, "LanServer iniciado en puerto 8080");
        } catch (IOException e) {
            Log.e(TAG, "No se pudo iniciar LanServer", e);
        }
    }

    /** Detiene el servidor LAN. */
    public void stopLanServer() {
        if (lanServer != null) {
            lanServer.stop();
            lanServer = null;
            Log.d(TAG, "LanServer detenido");
        }
    }

    public boolean isLanServerRunning() {
        return lanServer != null && lanServer.isAlive();
    }

    // ── Activity lifecycle ─────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        webView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopLanServer();
    }
}
