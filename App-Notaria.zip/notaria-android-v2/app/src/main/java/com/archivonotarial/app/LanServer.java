package com.archivonotarial.app;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import fi.iki.elonen.NanoHTTPD;

/**
 * Servidor HTTP embebido (puerto 8080).
 *
 * Endpoints:
 *   GET  /api/escrituras          → devuelve JSON array
 *   POST /api/escrituras          → upsert de un objeto (usa campo "id")
 *   GET  /api/escrituras/{id}     → devuelve un objeto
 *   DELETE /api/escrituras/{id}   → elimina por id
 *
 *   GET  /api/actividad           → devuelve JSON array
 *   POST /api/actividad           → agrega entrada al log
 *
 * Los datos se guardan en archivos JSON dentro del almacenamiento
 * interno de la app:  <filesDir>/lan_escrituras.json
 *                     <filesDir>/lan_actividad.json
 *
 * El cliente (otro celular) hace fetch() contra http://<IP_SERVIDOR>:8080/api/...
 */
public class LanServer extends NanoHTTPD {

    private static final String TAG = "LanServer";
    private static final int PORT = 8080;
    private static final String FILE_ESCRITURAS = "lan_escrituras.json";
    private static final String FILE_ACTIVIDAD  = "lan_actividad.json";

    /** Callback para notificar accesos al WebView (hilo UI). */
    public interface AccessListener {
        void onAccess(String ip, String ua, String nombre);
    }

    private final File filesDir;
    private AccessListener accessListener;

    public LanServer(Context ctx) throws IOException {
        super(PORT);
        this.filesDir = ctx.getFilesDir();
    }

    public void setAccessListener(AccessListener l) {
        this.accessListener = l;
    }

    // ── CORS helper ────────────────────────────────────────────────────
    private Response addCors(Response r) {
        r.addHeader("Access-Control-Allow-Origin", "*");
        r.addHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
        r.addHeader("Access-Control-Allow-Headers", "Content-Type, X-Client-UA, X-Client-Name");
        return r;
    }

    private Response json(String body) {
        return addCors(newFixedLengthResponse(Response.Status.OK,
                "application/json; charset=utf-8", body));
    }

    private Response jsonError(Response.Status status, String msg) {
        return addCors(newFixedLengthResponse(status,
                "application/json; charset=utf-8",
                "{\"error\":\"" + msg + "\"}"));
    }

    // ── Main router ────────────────────────────────────────────────────
    @Override
    public Response serve(IHTTPSession session) {
        String uri    = session.getUri();           // e.g. /api/escrituras/42
        Method method = session.getMethod();
        String ua     = session.getHeaders().getOrDefault("x-client-ua", "");
        String nombre = session.getHeaders().getOrDefault("x-client-name", "");
        String ip     = session.getHeaders().getOrDefault("http-client-ip",
                        session.getHeaders().getOrDefault("remote-addr",
                        session.getRemoteIpAddress() != null ? session.getRemoteIpAddress() : ""));

        Log.d(TAG, method + " " + uri + " [" + ip + "] " + nombre);

        // Notificar acceso al WebView
        if (accessListener != null && !ip.isEmpty()) {
            accessListener.onAccess(ip, ua, nombre);
        }

        // Pre-flight CORS
        if (method == Method.OPTIONS) {
            return addCors(newFixedLengthResponse(""));
        }

        // /api/escrituras  (colección)
        if (uri.equals("/api/escrituras")) {
            if (method == Method.GET)    return handleGetAll(FILE_ESCRITURAS);
            if (method == Method.POST)   return handleUpsert(session, FILE_ESCRITURAS);
        }

        // /api/escrituras/{id}
        if (uri.startsWith("/api/escrituras/")) {
            String idStr = uri.substring("/api/escrituras/".length());
            if (method == Method.DELETE) return handleDelete(idStr, FILE_ESCRITURAS);
            if (method == Method.GET)    return handleGetOne(idStr, FILE_ESCRITURAS);
        }

        // /api/actividad  (solo GET y POST)
        if (uri.equals("/api/actividad")) {
            if (method == Method.GET)  return handleGetAll(FILE_ACTIVIDAD);
            if (method == Method.POST) return handleAppend(session, FILE_ACTIVIDAD);
        }

        return jsonError(Response.Status.NOT_FOUND, "Not found");
    }

    // ── Handlers ───────────────────────────────────────────────────────

    /** GET  /api/{recurso}  → devuelve el array completo */
    private Response handleGetAll(String fileName) {
        String content = readFile(fileName);
        if (content == null) content = "[]";
        return json(content);
    }

    /** GET  /api/escrituras/{id}  → un objeto */
    private Response handleGetOne(String idStr, String fileName) {
        try {
            int id = Integer.parseInt(idStr);
            JSONArray arr = readArray(fileName);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (obj.optInt("id", -1) == id) return json(obj.toString());
            }
            return jsonError(Response.Status.NOT_FOUND, "Not found");
        } catch (Exception e) {
            return jsonError(Response.Status.INTERNAL_ERROR, e.getMessage());
        }
    }

    /**
     * POST /api/escrituras  → upsert:
     *   si ya existe un objeto con el mismo "id", lo reemplaza;
     *   si no, lo agrega al inicio del array.
     */
    private Response handleUpsert(IHTTPSession session, String fileName) {
        try {
            String body = readBody(session);
            JSONObject incoming = new JSONObject(body);
            JSONArray arr = readArray(fileName);

            int incomingId = incoming.optInt("id", -1);
            boolean found = false;
            if (incomingId != -1) {
                for (int i = 0; i < arr.length(); i++) {
                    if (arr.getJSONObject(i).optInt("id", -1) == incomingId) {
                        arr.put(i, incoming);
                        found = true;
                        break;
                    }
                }
            }
            if (!found) {
                // Insertar al inicio: construir nuevo array
                JSONArray newArr = new JSONArray();
                newArr.put(incoming);
                for (int i = 0; i < arr.length(); i++) newArr.put(arr.get(i));
                arr = newArr;
            }

            writeFile(fileName, arr.toString());
            return json("{\"ok\":true}");
        } catch (Exception e) {
            Log.e(TAG, "upsert error", e);
            return jsonError(Response.Status.INTERNAL_ERROR, e.getMessage());
        }
    }

    /** DELETE /api/escrituras/{id} */
    private Response handleDelete(String idStr, String fileName) {
        try {
            int id = Integer.parseInt(idStr);
            JSONArray arr = readArray(fileName);
            JSONArray newArr = new JSONArray();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.getJSONObject(i);
                if (obj.optInt("id", -1) != id) newArr.put(obj);
            }
            writeFile(fileName, newArr.toString());
            return json("{\"ok\":true}");
        } catch (Exception e) {
            return jsonError(Response.Status.INTERNAL_ERROR, e.getMessage());
        }
    }

    /** POST /api/actividad → agrega entrada al principio (max 200) */
    private Response handleAppend(IHTTPSession session, String fileName) {
        try {
            String body = readBody(session);
            JSONObject entry = new JSONObject(body);
            JSONArray arr = readArray(fileName);

            JSONArray newArr = new JSONArray();
            newArr.put(entry);
            for (int i = 0; i < Math.min(arr.length(), 199); i++) newArr.put(arr.get(i));

            writeFile(fileName, newArr.toString());
            return json("{\"ok\":true}");
        } catch (Exception e) {
            return jsonError(Response.Status.INTERNAL_ERROR, e.getMessage());
        }
    }

    // ── File helpers ───────────────────────────────────────────────────

    private String readFile(String name) {
        File f = new File(filesDir, name);
        if (!f.exists()) return null;
        try (FileReader fr = new FileReader(f)) {
            StringBuilder sb = new StringBuilder((int) f.length());
            char[] buf = new char[4096];
            int n;
            while ((n = fr.read(buf)) != -1) sb.append(buf, 0, n);
            return sb.toString();
        } catch (IOException e) {
            Log.e(TAG, "readFile " + name, e);
            return null;
        }
    }

    private JSONArray readArray(String name) {
        String raw = readFile(name);
        if (raw == null || raw.trim().isEmpty()) return new JSONArray();
        try { return new JSONArray(raw); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void writeFile(String name, String content) throws IOException {
        File f = new File(filesDir, name);
        try (FileWriter fw = new FileWriter(f, false)) {
            fw.write(content);
        }
    }

    /** Lee el body completo de una petición POST. */
    private String readBody(IHTTPSession session) throws IOException, NanoHTTPD.ResponseException {
        Map<String, String> files = new java.util.HashMap<>();
        session.parseBody(files);
        // NanoHTTPD pone el body en files bajo la clave "postData"
        String body = files.get("postData");
        return body != null ? body : "";
    }
}
