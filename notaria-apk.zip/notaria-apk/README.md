# ArchivoNotarial — APK Builder

## Cómo obtener el APK

### Opción 1 — GitHub Actions (automático)
1. Sube este proyecto a un repositorio GitHub
2. Ve a la pestaña **Actions**
3. El workflow `Build APK` se ejecuta automáticamente al hacer push
4. Cuando termine (≈5 min), descarga el APK desde **Artifacts → ArchivoNotarial-debug**

### Opción 2 — Ejecutar manualmente
Ve a **Actions → Build APK → Run workflow**

---

## Actualizar la app
Cuando tengas una nueva versión del HTML:
1. Reemplaza `www/index.html` con el nuevo archivo
2. Haz commit y push
3. GitHub Actions compila y genera el nuevo APK automáticamente

---

## Estructura del proyecto
```
notaria-apk/
├── www/
│   └── index.html          ← La app completa
├── .github/
│   └── workflows/
│       └── build-apk.yml   ← Script de compilación
├── capacitor.config.json   ← Configuración de la app
├── package.json
└── .gitignore
```

## Notas
- El APK generado es **debug** (no firmado para producción)
- Para instalar en Android: activar "Fuentes desconocidas" en Ajustes
- Compatible con Android 6.0+
